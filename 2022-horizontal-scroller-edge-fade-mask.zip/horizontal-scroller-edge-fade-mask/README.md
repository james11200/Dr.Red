# Horizontal scroller edge fade mask

A Pen created on CodePen.io. Original URL: [https://codepen.io/argyleink/pen/qBoryoL](https://codepen.io/argyleink/pen/qBoryoL).

